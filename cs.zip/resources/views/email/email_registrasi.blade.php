<!DOCTYPE html>
<html>
<head>
    <title>Cobaan</title>
</head>
<body>
   <h1>Hai email</h1>
   
    <p>Thank you</p>
</body>
</html>