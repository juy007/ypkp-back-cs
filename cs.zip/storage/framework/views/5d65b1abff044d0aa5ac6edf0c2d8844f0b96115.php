<!DOCTYPE html>
<html>
<head>
    <title>Cobaan</title>
</head>
<body>
   <h1>Hai email</h1>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\ypkpback\resources\views/email/email_registrasi.blade.php ENDPATH**/ ?>