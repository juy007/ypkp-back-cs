<div style="width: 650px;padding-right: 20px;padding-left: 20px;padding-bottom: 40px;">
	<table border="0" style="width: 100%;">
		<tr>
			<td><img style="height:150px;" src=<?php echo e(asset('assets/images/logo.png')); ?>></td>
			<td align="center" valign="middle" style="">
				<h3 style="margin-top:10px;">Data Calon Mahasiswa</h3><br>
				<h3 style="margin-top:-20px;">Universitas Sangga Buana YPKP Bandung</h3><br>
				<p style="margin-top:-20px;font-size: 13px;">Jl. PH.H. Mustofa No.68, Cikutra, Kec. Cibeunying Kidul Kota Bandung, Jawa Barat 40124</p>
			</td>
		</tr>
	</table><hr><br>
	<table border="0" style="width: 100%;">
		<tr>
			<td width="140"><img src="<?php echo e(asset('uploads/dokumen/foto')); ?>/<?php echo e($data['data']->file_foto); ?>" alt="Admin" class="p-1 bg-danger" width="110"></td>
			<td><h2><?php echo e($data['data']->nama); ?></h2></td>
		</tr>
	</table><hr><br>
	<table border="0" style="width: 100%;font-size: 16px;">
		<tr>
			<td width="200" height="40" valign="middle">Gelombang</td>
			<td>: <?php echo e($data['gelombang']->nama_gelombang); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Tempat, Tanggal Lahir</td>
			<td>: <?php echo e($data['data']->tempat_lahir); ?>, <?php echo e(date('d-m-Y', strtotime($data['data']->tanggal_lahir))); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Alamat</td>
			<td>: <?php echo e($data['data']->alamat); ?> Kec.<?php echo e($data['data']->kecamatan); ?> <?php echo e($data['data']->kota); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Kode Pos</td>
			<td>: <?php echo e($data['data']->pos); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">E-mail</td>
			<td>: <?php echo e($data['data']->email); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Telepon</td>
			<td>: <?php echo e($data['data']->telepon); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Whatsapp</td>
			<td>: <?php echo e($data['data']->whatsapp); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Jurusan</td>
			<td>: <?php echo e($data['data']->jurusan); ?></td>
		</tr>
		<tr>
			<td width="200" height="40" valign="middle">Waktu Pendaftaran</td>
			<td>: <?php echo e(date('d-m-Y', strtotime($data['data']->tanggal_input))); ?> <?php echo e($data['data']->time); ?></td>
		</tr>
		
	</table>
	<hr>
</div><?php /**PATH C:\xampp\htdocs\ypkpback\resources\views/data_pmb_pdf.blade.php ENDPATH**/ ?>