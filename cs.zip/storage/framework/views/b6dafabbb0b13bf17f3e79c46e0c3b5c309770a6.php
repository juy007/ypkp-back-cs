<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
	<div class="page-content">
	
		<div class="container">
			<div class="main-body">
				<div class="row">
					<div class="col-lg-8">
						<div class="card">
							<div class="card-body">
								<a href="<?php echo e(url('data-pmb')); ?>/<?php echo e($data['gelombang']->id_gelombang); ?>" class="btn btn-primary btn-sm"><i class='bx bx-chevron-left-circle'></i> Kembali</a>
								<div class="d-flex flex-column align-items-center text-center">
									<img src="<?php echo e($data['back_url']); ?>uploads/dokumen/foto/<?php echo e($data['data']->file_foto); ?>" alt="Admin" class="p-1 bg-danger" width="110">
									<div class="mt-3">
										<h4><?php echo e($data['data']->nama); ?></h4>
										<p class="text-muted font-size-sm"><?php echo e($data['gelombang']->nama_gelombang); ?></p>
										<!--
										<p class="text-secondary mb-1"></p>
										<p class="text-muted font-size-sm">Bay Area, San Francisco, CA</p>
										<button class="btn btn-primary">Follow</button>
										<button class="btn btn-outline-primary">Message</button>
										-->
									</div>
								</div>
								<hr class="my-4" />
								<ul class="list-group list-group-flush" id="print">
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Tempat, Tanggal Lahir</h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->tempat_lahir); ?>, <?php echo e(date('d-m-Y', strtotime($data['data']->tanggal_lahir))); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Alamat </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->alamat); ?> Kec.<?php echo e($data['data']->kecamatan); ?> <?php echo e($data['data']->kota); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Kode Pos </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->pos); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">E-mail </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->email); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Telepon </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->telepon); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Whatsapp </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->whatsapp); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Jurusan </h6>
										
										<span class="text-secondary"> : <?php echo e($data['data']->jurusan); ?></span>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Ijazah </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/ijazah/<?php echo e($data['data']->file_ijazah); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Transkip Nilai </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/transkip/<?php echo e($data['data']->file_transkip); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									<?php if(!empty($data['data']->file_toefl)): ?>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Toefl </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/toefl/<?php echo e($data['data']->file_toefl); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									<?php endif; ?>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">KTP </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/ktp'/<?php echo e($data['data']->file_ktp); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Formulir </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/formulir/<?php echo e($data['data']->file_formulir); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Pembayaran </h6>
										
										: <a href="<?php echo e($data['back_url']); ?>uploads/dokumen/pembayaran/<?php echo e($data['data']->file_pembayaran); ?>" download class="btn btn-primary btn-sm">Unduh</a>
									</li>
									

									<li class="list-group-item d-flex align-items-center flex-wrap">
										<h6 class="mb-0 col-lg-4">Waktu pendaftaran </h6>
										
										<span class="text-secondary"> : <?php echo e(date('d-m-Y', strtotime($data['data']->tanggal_input))); ?> <?php echo e($data['data']->time); ?></span>
									</li>
									
								</ul>
								<hr class="my-4" />
								<div class="d-flex flex-column align-items-center text-center">
									<div class="mt-3">
										<a href="<?php echo e(url('data-pmb-cetak')); ?>/<?php echo e($data['data']->id_pendaftar); ?>" target="_blank" class="btn btn-primary">Cetak</a>
										<a href="<?php echo e(url('data-pmb-pdf')); ?>/<?php echo e($data['data']->id_pendaftar); ?>" class="btn btn-outline-primary">Unduh PDF</a>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ypkpcs\resources\views/data_pmb_detail.blade.php ENDPATH**/ ?>